<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:23 --> Query error:  - Invalid query: SHOW TABLES FROM `forum`
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:23 --> Query error:  - Invalid query: UPDATE `tec_sessions` SET `timestamp` = 1568955623
WHERE `id` = ''
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/saleem/Sites/forum/lib/database/DB_driver.php:1782) /Users/saleem/Sites/forum/lib/core/Common.php 570
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:23 --> Query error:  - Invalid query: SELECT RELEASE_LOCK('2d030304d7d41ce9ae7b86067b2f7d39') AS ci_session_lock
ERROR - 2019-09-20 13:00:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/saleem/Sites/forum/lib/database/DB_driver.php:1782) /Users/saleem/Sites/forum/lib/core/Common.php 570
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:49 --> Query error:  - Invalid query: SHOW TABLES FROM `forum`
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:49 --> Query error:  - Invalid query: INSERT INTO `tec_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('', '', 1568955649, '')
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/saleem/Sites/forum/lib/database/DB_driver.php:1782) /Users/saleem/Sites/forum/lib/core/Common.php 570
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/forum/lib/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-09-20 13:00:49 --> Query error:  - Invalid query: SELECT RELEASE_LOCK('955ebc1f983256e84bd9e767bfd0960c') AS ci_session_lock
ERROR - 2019-09-20 13:00:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/saleem/Sites/forum/lib/database/DB_driver.php:1782) /Users/saleem/Sites/forum/lib/core/Common.php 570
ERROR - 2019-09-20 13:01:01 --> Severity: Notice --> Undefined property: stdClass::$subscription /Users/saleem/Sites/forum/app/models/Auth_model.php 1193
ERROR - 2019-09-20 13:02:17 --> Severity: Notice --> Undefined property: stdClass::$subscription /Users/saleem/Sites/forum/app/models/Auth_model.php 1193
