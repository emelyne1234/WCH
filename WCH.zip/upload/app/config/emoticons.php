<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| SEmoticons
| -------------------------------------------------------------------
*/

$emoticons = array(

//	emoticon		image name						width	height	alt

	':)'			=>	array('smail.png',			'19',	'19',	'smail'),
	':angry:'		=>	array('angry.png',			'19',	'19',	'angry'),
	':ninja:'		=>	array('ninja.png',			'19',	'19',	'ninja'),
	':angel:'		=>	array('angel.png',			'19',	'19',	'angel'),
	'8-)'			=>	array('cool.png',			'19',	'19',	'cool'),
	':\'('			=>	array('cwy.png',			'19',	'19',	'cool'),
	':ermm:'		=>	array('ermm.png',			'19',	'19',	'ermm'),
	':D'			=>	array('grin.png',			'19',	'19',	'grin'),
	':P'			=>	array('tongue.png',			'19',	'19',	'tongue'),
	'<3'			=>	array('heart.png',			'19',	'19',	'heart'),
	':('			=>	array('sad.png',			'19',	'19',	'sad'),
	':O'			=>	array('shocked.png',		'19',	'19',	'shocked'),
	':)'			=>	array('wink.png',			'19',	'19',	'wink'),
	':ermm:'		=>	array('ermm.png',			'19',	'19',	'ermm'),
	':alien:'		=>	array('alien.png',			'19',	'19',	'alien'),
	':blink:'		=>	array('blink.png',			'19',	'19',	'blink'),
	':blush:'		=>	array('blush.png',			'19',	'19',	'blush'),
	':cheerful:'	=>	array('cheerful.png',		'19',	'19',	'cheerful'),
	':devil:'		=>	array('devil.png',			'19',	'19',	'devil'),
	':dizzy:'		=>	array('dizzy.png',			'19',	'19',	'dizzy'),
	':getlost:'		=>	array('getlost.png',		'19',	'19',	'getlost'),
	':happy:'		=>	array('happy.png',			'19',	'19',	'happy'),
	':kissing:'		=>	array('kissing.png',		'19',	'19',	'kissing'),
	':pouty:'		=>	array('pouty.png',			'19',	'19',	'pouty'),
	':pinch:'		=>	array('pinch.png',			'19',	'19',	'pinch'),
	':sick:'		=>	array('sick.png',			'19',	'19',	'sick'),
	':sideways:'	=>	array('sideways.png',		'19',	'19',	'sideways'),
	':silly:'		=>	array('silly.png',			'19',	'19',	'silly'),
	':sleeping:'	=>	array('sleeping.png',		'19',	'19',	'sleeping'),
	':unsure:'		=>	array('unsure.png',			'19',	'19',	'unsure'),
	':woot:'		=>	array('w00t.png',			'19',	'19',	'woot'),
	':wassat:'		=>	array('wassat.png',			'19',	'19',	'wassat'),

);
