## Simple Forum

### Documentation for [Simple Forum](http://codecanyon.net/item/simple-forum-responsive-bulletin-board/13289844?ref=Tecdiary)

###### View Links: [rawgit](http://rawgit.com/tecdiary/forum-guide/gh-pages/index.html) | [gh-pages](http://tecdiary.github.io/forum-guide/)

Please read this documentation before asking us anything. As you know the support is no more free, you might need to pay $5 for any question that is already listed in the documentation. So save your money and time, read the documentation. If you can't find the answer then you can contact us by emailing to support@tecdiary.com

Thank you
